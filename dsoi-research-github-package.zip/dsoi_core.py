import torch
import torch.nn as nn
import torch.nn.functional as F


class DSOI_Core(nn.Module):
    """DSOI v0.3 research prototype."""

    def __init__(self, input_dim=2, hidden_dim=16, output_dim=1):
        super().__init__()
        self.hidden_dim = hidden_dim

        self.input_layer = nn.Linear(input_dim, hidden_dim)
        self.output_layer = nn.Linear(hidden_dim, output_dim)

        # Learnable synaptic strengths.
        self.synaptic_weights = nn.Parameter(
            torch.randn(hidden_dim, hidden_dim) * 0.15
        )

        # Learnable connectivity logits.
        self.connectivity_logits = nn.Parameter(
            torch.randn(hidden_dim, hidden_dim) * 0.1
        )

    def compute_ste_mask(self):
        """Create a hard connectivity mask with a straight-through estimator."""
        prob = torch.sigmoid(self.connectivity_logits)
        hard_mask = (prob > 0.5).float()

        # Forward pass uses the hard mask; backward pass uses the
        # differentiable probability as a surrogate gradient.
        mask = hard_mask - prob.detach() + prob

        # Remove self-connections.
        eye = torch.eye(
            self.hidden_dim,
            device=self.synaptic_weights.device
        )

        return mask * (1.0 - eye)

    def forward(self, x):
        h = torch.tanh(self.input_layer(x))

        mask = self.compute_ste_mask()
        dynamic_weights = self.synaptic_weights * mask

        h_plastic = torch.tanh(h @ dynamic_weights)
        h_total = h + h_plastic

        return self.output_layer(h_total)

    def get_sparsity_ratio(self):
        """Return active connections, total possible connections and sparsity."""
        with torch.no_grad():
            prob = torch.sigmoid(self.connectivity_logits)

            # Exclude diagonal self-connections from the count.
            eye = torch.eye(
                self.hidden_dim,
                device=prob.device
            )
            prob = prob * (1.0 - eye)

            active = (prob > 0.5).float().sum().item()
            total = self.hidden_dim * (self.hidden_dim - 1)

            sparsity = 1.0 - (active / total)

            return int(active), total, sparsity


def run_xor_experiment():
    """Run the current small XOR proof-of-concept."""
    X = torch.tensor([
        [0.0, 0.0],
        [0.0, 1.0],
        [1.0, 0.0],
        [1.0, 1.0],
    ])

    Y = torch.tensor([
        [0.0],
        [1.0],
        [1.0],
        [0.0],
    ])

    model = DSOI_Core(
        input_dim=2,
        hidden_dim=16,
        output_dim=1
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=0.03
    )

    print("DSOI Core Prototype Training Started...")
    print("=" * 60)

    epochs = 2000

    for epoch in range(epochs):
        optimizer.zero_grad()

        logits = model(X)

        task_loss = F.binary_cross_entropy_with_logits(
            logits,
            Y
        )

        prob = torch.sigmoid(model.connectivity_logits)

        # Encourage fewer connections.
        sparsity_loss = 0.005 * torch.mean(prob)

        total_loss = task_loss + sparsity_loss

        total_loss.backward()
        optimizer.step()

        if epoch % 400 == 0:
            active, total, sparsity = model.get_sparsity_ratio()

            print(
                f"Epoch {epoch:4d} | "
                f"Loss: {total_loss.item():.5f} | "
                f"Active Synapses: {active}/{total} | "
                f"Sparsity: {sparsity * 100:.1f}%"
            )

    print("=" * 60)
    print("TRAINING COMPLETED SUCCESSFULLY!\n")

    print("============================================================")
    print("DSOI v0.3 XOR PROTOTYPE RESULTS")
    print("============================================================")

    with torch.no_grad():
        test_logits = model(X)
        test_probs = torch.sigmoid(test_logits)
        test_preds = (test_probs > 0.5).float()

    for i in range(len(X)):
        print(
            f"Input: {X[i].tolist()} | "
            f"Expected: {int(Y[i].item())} | "
            f"Predicted: {int(test_preds[i].item())} | "
            f"Probability: {test_probs[i].item():.4f}"
        )

    active, total, sparsity = model.get_sparsity_ratio()

    print("-" * 60)
    print(f"Total Possible Connections : {total}")
    print(f"DSOI Pruned Connections    : {total - active}")
    print(f"Final Active Connections   : {active}")
    print(f"Topological Sparsity       : {sparsity * 100:.2f}%")
    print("============================================================")


if __name__ == "__main__":
    run_xor_experiment()
