# DSOI — Dynamic Self-Organizing Intelligence

**Founder & Lead Researcher:** G. Harish Karthick

DSOI (Dynamic Self-Organizing Intelligence) is an early-stage research project exploring whether neural networks can learn useful internal connectivity structures together with their numerical parameters.

## Research Hypothesis

Traditional neural networks generally use a predefined connectivity structure.

DSOI explores a different approach:

> Can a neural network learn which internal connections it needs and reduce unnecessary connections during training?

The current prototype investigates this idea using:

- Learnable connectivity logits
- Differentiable connectivity probabilities
- Straight-Through Estimation (STE)
- Learnable synaptic weights
- Topological sparsity regularization

## Current Status

**Stage: Early research prototype**

The current implementation has been tested on the XOR classification problem.

XOR is being used as a small nonlinear sanity check for the DSOI mechanism. It should not be interpreted as evidence that DSOI currently outperforms modern neural-network architectures.

Larger experiments are planned.

## Core Idea

The prototype uses a learnable connectivity matrix to mask a learnable synaptic weight matrix.

Conceptually:

`h_next = h + tanh(h @ (W ⊙ M))`

where `W` represents synaptic weights and `M` represents the learned connectivity mask.

The connectivity mask uses a straight-through estimator so that hard binary connectivity can be used in the forward pass while a differentiable surrogate is used during optimization.

## Planned Evaluation

Future experiments will compare DSOI with appropriate baseline architectures using:

- MNIST
- Additional classification datasets
- Multiple random seeds
- Accuracy
- Active connections
- Structural sparsity
- Parameter count
- Memory usage
- Inference latency
- Computational cost

The project will report measured results rather than assuming that structural sparsity automatically produces hardware-level speed or energy improvements.

## Repository Structure

```text
dsoi-research/
├── README.md
├── dsoi_core.py
├── requirements.txt
├── experiments/
├── benchmarks/
├── results/
└── docs/
```

## Running the Current Prototype

Install dependencies:

```bash
pip install -r requirements.txt
```

Run:

```bash
python dsoi_core.py
```

The program trains the current DSOI prototype on XOR and reports predictions and learned connectivity statistics.

## Roadmap

### DSOI v0.3
- Initial learnable connectivity prototype
- STE-based topology
- XOR sanity test

### DSOI v0.4
- Reproducible experiment system
- Dense baseline comparison
- MNIST evaluation
- Multi-seed experiments

### DSOI v0.5
- Hardware-aware profiling
- Runtime and memory measurements
- Larger neural architectures

### Future
- Dynamic/input-dependent connectivity
- Larger vision experiments
- Sequence and language experiments
- Potential developer/runtime tooling

## Research Integrity

DSOI is an experimental research project.

The current repository does **not** claim state-of-the-art performance, proven energy savings, or superiority over existing AI architectures.

Those claims will only be made if reproducible experiments provide evidence for them.

## Founder

**G. Harish Karthick**

DSOI is being developed as an independent early-stage AI research project.
